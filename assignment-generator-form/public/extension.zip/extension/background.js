// chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
//   if (request.action === "getGeminiSession") {
//     // Google target domain se dynamic auth parameters khinch kar filter karna
//     chrome.cookies.getAll({ domain: "google.com" }, (cookies) => {
//       const activeAuthTokens = cookies.filter(
//         c => c.name === "__Secure-1PSID" || c.name === "__Secure-1PSIDTS"
//       );
      
//       if (activeAuthTokens.length === 0) {
//         sendResponse({ status: "logged_out", cookies: [] });
//       } else {
//         // Playwright application context standard schema mapping
//         const playwrightReadyCookies = activeAuthTokens.map(c => ({
//           name: c.name,
//           value: c.value,
//           domain: c.domain,
//           path: c.path,
//           expires: c.expirationDate || Math.floor(Date.now() / 1000) + 3600,
//           httpOnly: c.httpOnly,
//           secure: c.secure,
//           sameSite: "None"
//         }));
//         sendResponse({ status: "success", cookies: playwrightReadyCookies });
//       }
//     });
//     return true; // Asynchronous message sequence handling lock
//   }
// });

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  if (request.action === "getGeminiSession") {
    // 🚀 FIXED: Sirf 'google.com' nahi, balke sabhi sub-domains aur related session layers ko wild-card target kiya
    chrome.cookies.getAll({}, (cookies) => {
      
      if (cookies.length === 0) {
        sendResponse({ status: "logged_out", cookies: [] });
        return;
      }

      // Google dashboard validation ko satisfy karne wale domains ko map karna
      const googleDomainBundle = cookies.filter(c => 
        c.domain.includes("google.com") || 
        c.domain.includes("gemini.google.com") || 
        c.domain.includes("accounts.google.com")
      );

      if (googleDomainBundle.length === 0) {
        sendResponse({ status: "logged_out", cookies: [] });
        return;
      }

      // Playwright storage_state model format signature compilation
      const playwrightReadyCookies = googleDomainBundle.map(c => ({
        name: c.name,
        value: c.value,
        domain: c.domain.startsWith('.') ? c.domain : `.${c.domain}`, // 🚀 CROSS-DOMAIN COMPLIANCE FIX
        path: c.path,
        expires: c.expirationDate || Math.floor(Date.now() / 1000) + 3600,
        httpOnly: c.httpOnly,
        secure: c.secure,
        sameSite: c.sameSite === "no_restriction" ? "None" : (c.sameSite === "lax" ? "Lax" : "Strict")
      }));

      // Output completely synced structured binary tokens map array
      sendResponse({ status: "success", cookies: playwrightReadyCookies });
    });
    return true; // Asynchronous sequence link lock
  }
});
